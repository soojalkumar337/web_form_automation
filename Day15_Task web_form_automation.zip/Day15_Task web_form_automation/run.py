import pandas as pd
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time
from selenium.webdriver.chrome.options import Options

# Setup logging
logging.basicConfig(filename='submission.log', level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger()

chrome_options = Options()
chrome_options.add_experimental_option("detach", True)
driver = webdriver.Chrome(options=chrome_options)

# CSV file read
df = pd.read_csv("data/input_data.csv")

form_url = "file:///E:/Internship/Day15_Task%20web_form_automation/form/demo_form.html"

for index, row in df.iterrows():
    driver.get(form_url)  # Reload form from start har bar

    driver.find_element(By.NAME, "name").clear()
    driver.find_element(By.NAME, "name").send_keys(row['name'])

    driver.find_element(By.NAME, "email").clear()
    driver.find_element(By.NAME, "email").send_keys(row['email'])

    driver.find_element(By.NAME, "address").clear()
    driver.find_element(By.NAME, "address").send_keys(row['address'])

    Select(driver.find_element(By.NAME, "gender")).select_by_visible_text(row['gender'].capitalize())



    checkbox = driver.find_element(By.NAME, "subscribe")
    if row['subscribe'].lower() == "yes":
        if not checkbox.is_selected():
            checkbox.click()
    else:
        if checkbox.is_selected():
            checkbox.click()

    driver.find_element(By.XPATH, '//input[@type="submit"]').click()
    time.sleep(1)

    driver.switch_to.alert.accept()

    logger.info(f"Form submitted successfully for {row['email']}")

driver.quit()
