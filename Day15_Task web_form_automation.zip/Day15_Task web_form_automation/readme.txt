📄 Automated Web Form Submission using Selenium
🚀 Project Overview
This project automates the process of submitting data into a web form using 
Python, Selenium, and CSV file handling.Instead of filling a form manually 
for multiple users, this script reads user data from a .csv file and 
automates the form submission process through the Chrome browser.

🛠️ Technologies Used
Python 3.10
Selenium WebDriver
Pandas
ChromeDriver

📂 Project Structure
web_form_automation/
├── data/
│   └── input_data.csv               # CSV file with user data
├── form/
│   └── demo_form.html               # Local demo HTML form for testing
├── submission.log                    # Log file storing submission status
├── run.py                             # Main Python script
├── requirements.txt                   # Python dependencies
└── README.md                          # Project documentation
📝 How It Works
Reads user data (name, email, address, gender, subscription choice) from input_data.csv.

Opens a local HTML form in the browser via Selenium.

Automatically fills out the form for each user and submits it.

Accepts browser alerts after submission.

Logs each successful submission in submission.log.

📥 CSV Input Format (data/input_data.csv)
name,email,address,gender,subscribe
soojal,kumar@gmail.com,khatrimohlla,Male,y
amrat,bajeer@gmail.com,bajeermohlla,Male,yes
bhom,bhom@gmail.com,sodhamohlla,Male,no
chen,cs@gmail.com,thakurmohlla,Male,yes
sarop,ss@gmail.com,sunohimohla,Male,no
Make sure gender matches dropdown options exactly (case-sensitive).

📄 Demo HTML Form (form/demo_form.html)
Simple demo HTML file with:

Text inputs

Dropdown

Checkbox

Submit button
Used to test this automation locally.

🔧 Setup Instructions
1️)Install Dependencies
pip install -r requirements.txt
2️) Run the Script
python run.py
📌 Output
Browser will open and automatically fill & submit forms.

submission.log will store success messages.

Sample submission.log:
2025-07-20 22:29:41,805 - Form submitted successfully for kumar@gmail.com
2025-07-20 22:29:43,436 - Form submitted successfully for bajeer@gmail.com
2025-07-20 22:29:45,004 - Form submitted successfully for bhom@gmail.com
2025-07-20 22:29:46,573 - Form submitted successfully for cs@gmail.com
2025-07-20 22:29:48,104 - Form submitted successfully for ss@gmail.com

🛡️ Error Handling
Invalid field names or missing dropdown options are handled.

Browser alert is automatically accepted.

Logs capture each success entry.

🚀 Future Improvements
Support for real websites

Screenshots on failure

Headless mode for production

Detailed JSON logs

👨‍💻 Developed By:
Soojal Kumar


